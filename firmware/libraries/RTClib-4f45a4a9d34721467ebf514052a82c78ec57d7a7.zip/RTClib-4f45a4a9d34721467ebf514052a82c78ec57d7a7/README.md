# RTClib
A fork of Jeelab's fantastic RTC library updated to add support for the high accuracy DS3231 and 
the wonderful CHRONODOT by macetech.com. Includes full-functioned example set for Chronodot.


